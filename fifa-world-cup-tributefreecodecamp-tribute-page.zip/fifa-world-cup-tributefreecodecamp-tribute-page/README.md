# FIFA world cup tribute - Freecodecamp Tribute Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/Facu-Tomasella/pen/KKeZVKB](https://codepen.io/Facu-Tomasella/pen/KKeZVKB).

